<?php
require_once __DIR__ . '/includes/functions.php';
$id = filter_input(INPUT_GET,'id',FILTER_VALIDATE_INT);
$stmt=$pdo->prepare("SELECT a.*,c.name AS category_name FROM addons a JOIN categories c ON c.id=a.category_id WHERE a.id=? AND a.status='approved' LIMIT 1");
$stmt->execute([$id ?: 0]); $a=$stmt->fetch();
if (!$a) { http_response_code(404); $page_title='Addon tidak ditemukan'; require __DIR__.'/includes/header.php'; echo '<div class="empty">Addon tidak ditemukan atau belum disetujui.</div>'; require __DIR__.'/includes/footer.php'; exit; }
$page_title=$a['title'];
require __DIR__.'/includes/header.php';
?>
<article class="detail">
<?php if($a['thumbnail']): ?><img class="detail-thumb" src="<?= e(BASE_URL.'/uploads/thumbnails/'.$a['thumbnail']) ?>" alt="<?= e($a['title']) ?>"><?php endif; ?>
<div class="section-head"><div><span class="category"><?= e($a['category_name']) ?></span><h1><?= e($a['title']) ?></h1><p>Diunggah oleh <strong><?= e($a['uploader_name']) ?></strong></p></div><a class="button" href="<?= e(BASE_URL) ?>/download.php?id=<?= (int)$a['id'] ?>">⬇ Download</a></div>
<div class="meta"><span>Versi <?= e($a['version']) ?></span><span><?= e(format_size((int)$a['file_size'])) ?></span><span><?= (int)$a['downloads'] ?> download</span><span><?= e(date('d M Y',strtotime($a['created_at']))) ?></span></div>
<h3>Deskripsi</h3><div class="detail-desc"><?= e($a['description']) ?></div>
<p class="help">Pastikan addon cocok dengan versi Minecraft kamu. Unduh hanya file yang kamu percaya.</p>
</article>
<?php require __DIR__ . '/includes/footer.php'; ?>
