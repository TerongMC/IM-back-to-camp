<?php
require_once __DIR__ . '/includes/functions.php';
$page_title = 'Upload Addon';
$categories = get_categories($pdo);
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  verify_csrf();
  $uploader = trim((string)($_POST['uploader_name'] ?? ''));
  $title = trim((string)($_POST['title'] ?? ''));
  $description = trim((string)($_POST['description'] ?? ''));
  $version = trim((string)($_POST['version'] ?? '1.0'));
  $categoryId = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT);
  if ($uploader === '' || mb_strlen($uploader) > 80) $errors[] = 'Nama uploader wajib diisi (maksimal 80 karakter).';
  if ($title === '' || mb_strlen($title) > 150) $errors[] = 'Nama addon wajib diisi (maksimal 150 karakter).';
  if ($description === '' || mb_strlen($description) > 10000) $errors[] = 'Deskripsi wajib diisi (maksimal 10.000 karakter).';
  if ($version === '' || mb_strlen($version) > 40) $errors[] = 'Versi wajib diisi (maksimal 40 karakter).';
  $catStmt = $pdo->prepare('SELECT id FROM categories WHERE id=?'); $catStmt->execute([$categoryId]);
  if (!$categoryId || !$catStmt->fetch()) $errors[] = 'Kategori tidak valid.';

  $file = $_FILES['addon_file'] ?? null;
  $allowed = ['mcpack','mcaddon','mcworld','zip'];
  $ext = strtolower(pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION));
  if (!$file || $file['error'] !== UPLOAD_ERR_OK) $errors[] = 'Pilih file addon dan pastikan upload selesai.';
  elseif (!in_array($ext, $allowed, true)) $errors[] = 'Format file harus .mcpack, .mcaddon, .mcworld, atau .zip.';
  elseif ($file['size'] < 1 || $file['size'] > MAX_ADDON_SIZE) $errors[] = 'Ukuran file maksimal 100 MB.';
  elseif (!is_uploaded_file($file['tmp_name'])) $errors[] = 'File upload tidak valid.';

  $thumb = $_FILES['thumbnail'] ?? null;
  $thumbExt = '';
  if ($thumb && $thumb['error'] !== UPLOAD_ERR_NO_FILE) {
    $thumbExt = strtolower(pathinfo((string)$thumb['name'], PATHINFO_EXTENSION));
    $finfo = new finfo(FILEINFO_MIME_TYPE); $mime = $finfo->file($thumb['tmp_name']);
    $mimeAllowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if ($thumb['error'] !== UPLOAD_ERR_OK || $thumb['size'] > MAX_THUMBNAIL_SIZE || !isset($mimeAllowed[$mime]) || !in_array($thumbExt,['jpg','jpeg','png','webp'],true)) $errors[] = 'Thumbnail harus JPG/PNG/WebP dan maksimal 5 MB.';
    else $thumbExt = $mimeAllowed[$mime];
  }

  if (!$errors) {
    if (!is_dir(UPLOAD_ADDON_DIR)) mkdir(UPLOAD_ADDON_DIR, 0755, true);
    if (!is_dir(UPLOAD_THUMB_DIR)) mkdir(UPLOAD_THUMB_DIR, 0755, true);
    $storedFile = safe_upload_name($ext);
    $storedThumb = null;
    if (!move_uploaded_file($file['tmp_name'], UPLOAD_ADDON_DIR . $storedFile)) $errors[] = 'Gagal menyimpan file. Periksa izin folder uploads.';
    if (!$errors && $thumb && $thumb['error'] === UPLOAD_ERR_OK) {
      $storedThumb = safe_upload_name($thumbExt);
      if (!move_uploaded_file($thumb['tmp_name'], UPLOAD_THUMB_DIR . $storedThumb)) { @unlink(UPLOAD_ADDON_DIR . $storedFile); $errors[] = 'Gagal menyimpan thumbnail.'; }
    }
    if (!$errors) {
      try {
        $slug = unique_slug($pdo, $title);
        $stmt = $pdo->prepare("INSERT INTO addons (uploader_name,category_id,title,slug,description,version,file_name,original_file_name,thumbnail,file_size,status) VALUES (?,?,?,?,?,?,?,?,?,?, 'pending')");
        $stmt->execute([$uploader,(int)$categoryId,$title,$slug,$description,$version,$storedFile,basename((string)$file['name']),$storedThumb,(int)$file['size']]);
        notice('success', 'Upload berhasil dikirim dan menunggu persetujuan admin.');
        redirect('upload.php');
      } catch (Throwable $e) {
        @unlink(UPLOAD_ADDON_DIR . $storedFile);
        if ($storedThumb) @unlink(UPLOAD_THUMB_DIR . $storedThumb);
        error_log($e->getMessage()); $errors[] = 'Tidak bisa menyimpan data. Periksa database.';
      }
    }
  }
}
require __DIR__ . '/includes/header.php';
?>
<section class="form-wrap"><div class="form-panel">
<h1>Upload Addon <span class="accent">↗</span></h1><p>Tanpa login. Masukkan nama yang ingin ditampilkan sebagai uploader. Upload akan diperiksa admin sebelum dipublikasikan.</p>
<?php foreach ($errors as $err): ?><div class="notice error"><?= e($err) ?></div><?php endforeach; ?>
<form method="post" enctype="multipart/form-data">
<?= csrf_field() ?>
<div class="form-grid">
<div class="field"><label for="uploader_name">Nama uploader *</label><input id="uploader_name" name="uploader_name" maxlength="80" required value="<?= e($_POST['uploader_name'] ?? '') ?>" placeholder="Contoh: CraxyDev"></div>
<div class="field"><label for="title">Nama addon *</label><input id="title" name="title" maxlength="150" required value="<?= e($_POST['title'] ?? '') ?>" placeholder="Contoh: Shadow PvP Pack"></div>
<div class="field"><label for="category_id">Kategori *</label><select id="category_id" name="category_id" required><option value="">Pilih kategori</option><?php foreach ($categories as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (string)($c['id']) === (string)($_POST['category_id'] ?? '') ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></div>
<div class="field"><label for="version">Versi *</label><input id="version" name="version" maxlength="40" required value="<?= e($_POST['version'] ?? '1.0') ?>" placeholder="1.0"></div>
<div class="field full"><label for="description">Deskripsi addon *</label><textarea id="description" name="description" maxlength="10000" required placeholder="Jelaskan fitur dan kompatibilitas addon..."><?= e($_POST['description'] ?? '') ?></textarea></div>
<div class="field full"><label for="addon-file">File addon *</label><input type="file" id="addon-file" name="addon_file" accept=".mcpack,.mcaddon,.mcworld,.zip" required><span class="help">Format: MCpack, MCaddon, MCworld, ZIP. Maksimal 100 MB.</span><span id="addon-filename" class="file-name">Belum ada file dipilih.</span></div>
<div class="field full"><label for="thumbnail">Thumbnail (opsional)</label><input type="file" id="thumbnail" name="thumbnail" accept=".jpg,.jpeg,.png,.webp"><span class="help">JPG, PNG, atau WebP. Maksimal 5 MB.</span><img id="thumbnail-preview" class="preview" alt="Preview thumbnail" hidden></div>
<div class="field full"><button class="button" type="submit">Kirim untuk ditinjau →</button></div>
</div></form></div></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
