<?php
declare(strict_types=1);

define('SITE_NAME', 'SHADOWNEX');
define('SITE_SLOGAN', 'Beyond Every Block.');
define('BASE_URL', 'http://localhost/SHADOWNEX'); // Ubah sesuai domain/folder hosting.
define('MAX_ADDON_SIZE', 100 * 1024 * 1024);
define('MAX_THUMBNAIL_SIZE', 5 * 1024 * 1024);
define('UPLOAD_ADDON_DIR', dirname(__DIR__) . '/uploads/addons/');
define('UPLOAD_THUMB_DIR', dirname(__DIR__) . '/uploads/thumbnails/');

date_default_timezone_set('Asia/Jakarta');
if (session_status() !== PHP_SESSION_ACTIVE) {
    $https = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params(['httponly'=>true, 'secure'=>$https, 'samesite'=>'Lax']);
    session_start();
}
