</main>
<footer class="footer">
  <div class="footer-brand">SHADOWNEX <span class="accent">/</span> Beyond Every Block.</div>
  <p>Platform berbagi addon Minecraft Bedrock. Unggah hanya file yang kamu miliki atau diizinkan untuk dibagikan.</p>
  <p class="muted">© <?= date('Y') ?> SHADOWNEX</p>
</footer>
</body>
</html>
