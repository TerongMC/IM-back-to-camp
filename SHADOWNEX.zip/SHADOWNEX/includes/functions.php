<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

function e(?string $v): string {
    return htmlspecialchars($v ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}
function verify_csrf(): void {
    $sent = $_POST['csrf_token'] ?? '';
    $saved = $_SESSION['csrf_token'] ?? '';
    if (!is_string($sent) || !is_string($saved) || $saved === '' || !hash_equals($saved, $sent)) {
        http_response_code(403);
        exit('Permintaan tidak valid. Muat ulang halaman.');
    }
}
function format_size(int $bytes): string {
    if ($bytes < 1024) return $bytes . ' B';
    if ($bytes < 1048576) return number_format($bytes / 1024, 1) . ' KB';
    if ($bytes < 1073741824) return number_format($bytes / 1048576, 1) . ' MB';
    return number_format($bytes / 1073741824, 2) . ' GB';
}
function make_slug(string $s): string {
    $s = strtolower(trim($s));
    $s = preg_replace('/[^a-z0-9]+/i', '-', $s) ?? '';
    return trim($s, '-') ?: 'addon';
}
function unique_slug(PDO $pdo, string $title): string {
    $base = substr(make_slug($title), 0, 150);
    $slug = $base; $n = 2;
    $q = $pdo->prepare('SELECT id FROM addons WHERE slug = ? LIMIT 1');
    while (true) {
        $q->execute([$slug]);
        if (!$q->fetch()) return $slug;
        $slug = $base . '-' . $n++;
    }
}
function notice(string $type, string $message): void {
    $_SESSION['flash'] = ['type'=>$type, 'message'=>$message];
}
function get_notice(): ?array {
    $n = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return is_array($n) ? $n : null;
}
function redirect(string $path): never {
    header('Location: ' . rtrim(BASE_URL, '/') . '/' . ltrim($path, '/'));
    exit;
}
function is_admin(): bool {
    return !empty($_SESSION['admin_ok']);
}
function require_admin(): void {
    if (!is_admin()) redirect('admin/login.php');
}
function get_categories(PDO $pdo): array {
    return $pdo->query('SELECT id,name,slug FROM categories ORDER BY name')->fetchAll();
}
function safe_upload_name(string $extension): string {
    return bin2hex(random_bytes(18)) . '.' . strtolower($extension);
}
