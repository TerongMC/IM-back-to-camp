<?php
$page_title = $page_title ?? SITE_NAME;
$flash = get_notice();
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#090b12">
<meta name="description" content="SHADOWNEX — tempat berbagi addon Minecraft Bedrock.">
<title><?= e($page_title) ?> | <?= e(SITE_NAME) ?></title>
<link rel="stylesheet" href="<?= e(BASE_URL) ?>/assets/css/style.css">
<script src="<?= e(BASE_URL) ?>/assets/js/app.js" defer></script>
</head>
<body>
<header class="topbar">
  <a class="brand" href="<?= e(BASE_URL) ?>/"><span class="brand-mark">S</span><span>SHADOW<span class="accent">NEX</span><small>BEYOND EVERY BLOCK.</small></span></a>
  <button class="menu-toggle" id="menu-toggle" aria-expanded="false" aria-controls="mobile-menu">☰</button>
  <nav id="mobile-menu" class="nav-links">
    <a href="<?= e(BASE_URL) ?>/">Beranda</a>
    <a href="<?= e(BASE_URL) ?>/upload.php">Upload Addon</a>
    <a href="<?= e(BASE_URL) ?>/search.php">Jelajahi</a>
    <a class="nav-admin" href="<?= e(BASE_URL) ?>/admin/login.php">Admin</a>
  </nav>
</header>
<main class="container">
<?php if ($flash): ?>
  <div class="notice <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
<?php endif; ?>
