<?php
require_once __DIR__ . '/../includes/functions.php';
if (is_admin()) redirect('admin/dashboard.php');
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  verify_csrf();
  $password=(string)($_POST['password']??'');
  $hash=(string)(get_setting_admin_hash($pdo));
  if ($hash !== '' && password_verify($password,$hash)) {
    session_regenerate_id(true); $_SESSION['admin_ok']=true; redirect('admin/dashboard.php');
  }
  $error='Password salah atau admin belum dikonfigurasi.';
}
function get_setting_admin_hash(PDO $pdo): string {
  $s=$pdo->prepare("SELECT setting_value FROM settings WHERE setting_key='admin_password_hash'"); $s->execute(); return (string)($s->fetchColumn() ?: '');
}
$page_title='Admin Login'; require __DIR__.'/../includes/header.php';
?>
<section class="form-wrap"><div class="form-panel"><h1>Admin <span class="accent">Login</span></h1><p>Area moderasi SHADOWNEX.</p><?php if($error): ?><div class="notice error"><?= e($error) ?></div><?php endif; ?><form method="post"><?= csrf_field() ?><div class="field"><label for="password">Password admin</label><input id="password" name="password" type="password" required autocomplete="current-password"></div><p class="help">Atur hash password admin melalui database. Petunjuk ada di README.</p><button class="button" style="margin-top:18px">Masuk</button></form></div></section>
<?php require __DIR__.'/../includes/footer.php'; ?>
