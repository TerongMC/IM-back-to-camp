<?php
require_once __DIR__ . '/../includes/functions.php'; require_admin();
$total=(int)$pdo->query("SELECT COUNT(*) FROM addons")->fetchColumn();
$pending=(int)$pdo->query("SELECT COUNT(*) FROM addons WHERE status='pending'")->fetchColumn();
$approved=(int)$pdo->query("SELECT COUNT(*) FROM addons WHERE status='approved'")->fetchColumn();
$page_title='Admin Dashboard'; require __DIR__.'/../includes/header.php';
?>
<div class="section-head"><div><h2>Dashboard Admin</h2><p>Kelola moderasi konten SHADOWNEX.</p></div><a class="button secondary" href="<?= e(BASE_URL) ?>/admin/logout.php">Logout admin</a></div>
<div class="addon-grid"><div class="form-panel"><span class="muted">Semua upload</span><h1><?= $total ?></h1></div><div class="form-panel"><span class="muted">Menunggu</span><h1><?= $pending ?></h1></div><div class="form-panel"><span class="muted">Dipublikasikan</span><h1><?= $approved ?></h1></div></div>
<a class="button" href="<?= e(BASE_URL) ?>/admin/addons.php">Kelola addon →</a>
<?php require __DIR__.'/../includes/footer.php'; ?>
