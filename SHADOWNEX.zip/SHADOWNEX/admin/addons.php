<?php
require_once __DIR__ . '/../includes/functions.php'; require_admin();
if ($_SERVER['REQUEST_METHOD']==='POST') {
  verify_csrf();
  $id=filter_input(INPUT_POST,'id',FILTER_VALIDATE_INT);
  $action=(string)($_POST['action']??'');
  if ($id && in_array($action,['approved','rejected','pending','delete'],true)) {
    $s=$pdo->prepare('SELECT file_name,thumbnail FROM addons WHERE id=?'); $s->execute([$id]); $old=$s->fetch();
    if ($old) {
      if ($action==='delete') {
        $pdo->prepare('DELETE FROM addons WHERE id=?')->execute([$id]);
        @unlink(UPLOAD_ADDON_DIR.basename($old['file_name']));
        if ($old['thumbnail']) @unlink(UPLOAD_THUMB_DIR.basename($old['thumbnail']));
      } else { $pdo->prepare('UPDATE addons SET status=? WHERE id=?')->execute([$action,$id]); }
      notice('success','Perubahan addon disimpan.');
    }
  }
  redirect('admin/addons.php');
}
$page_title='Moderasi Addon';
$rows=$pdo->query("SELECT a.*,c.name category_name FROM addons a JOIN categories c ON c.id=a.category_id ORDER BY FIELD(a.status,'pending','approved','rejected'),a.created_at DESC")->fetchAll();
require __DIR__.'/../includes/header.php';
?>
<div class="section-head"><div><h2>Moderasi Addon</h2><p>Periksa file dan deskripsi sebelum menyetujui publikasi.</p></div><a class="button secondary" href="<?= e(BASE_URL) ?>/admin/dashboard.php">← Dashboard</a></div>
<?php if(!$rows): ?><div class="empty">Belum ada upload.</div><?php endif; ?>
<div class="addon-grid"><?php foreach($rows as $a): ?><article class="addon-card"><div class="card-body"><span class="category"><?= e($a['category_name']) ?></span><h3><?= e($a['title']) ?></h3><p><?= e(mb_strimwidth($a['description'],0,180,'…','UTF-8')) ?></p><div class="meta"><span>Uploader: <?= e($a['uploader_name']) ?></span><span><?= e(format_size((int)$a['file_size'])) ?></span></div><p><span class="status <?= e($a['status']) ?>"><?= e(strtoupper($a['status'])) ?></span></p><div class="admin-actions"><?php foreach(['approved'=>'Setujui','pending'=>'Pending','rejected'=>'Tolak'] as $act=>$label): ?><form class="inline-form" method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$a['id'] ?>"><input type="hidden" name="action" value="<?= e($act) ?>"><button class="button secondary" type="submit"><?= e($label) ?></button></form><?php endforeach; ?><form class="inline-form" method="post" data-confirm="Hapus addon ini secara permanen?"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$a['id'] ?>"><input type="hidden" name="action" value="delete"><button class="button danger" type="submit">Hapus</button></form></div></div></article><?php endforeach; ?></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
