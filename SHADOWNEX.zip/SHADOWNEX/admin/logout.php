<?php
require_once __DIR__ . '/../includes/functions.php';
unset($_SESSION['admin_ok']);
session_regenerate_id(true);
redirect('admin/login.php');
