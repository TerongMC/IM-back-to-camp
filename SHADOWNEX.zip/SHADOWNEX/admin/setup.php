<?php
// Jalankan sekali untuk membuat hash password admin, lalu HAPUS file ini dari hosting.
require_once __DIR__ . '/../includes/functions.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
  $page_title='Setup Admin'; require __DIR__.'/../includes/header.php';
  echo '<section class="form-wrap"><div class="form-panel"><h1>Setup Admin Password</h1><p>Gunakan sekali saja. Setelah selesai, hapus admin/setup.php.</p><form method="post">'.csrf_field().'<div class="field"><label>Password admin baru (minimal 12 karakter)</label><input name="password" type="password" minlength="12" required></div><button class="button" style="margin-top:18px">Simpan password</button></form></div></section>';
  require __DIR__.'/../includes/footer.php'; exit;
}
verify_csrf();
$password=(string)($_POST['password']??'');
if (strlen($password)<12) exit('Password minimal 12 karakter.');
$hash=password_hash($password,PASSWORD_DEFAULT);
$stmt=$pdo->prepare("UPDATE settings SET setting_value=? WHERE setting_key='admin_password_hash'");
$stmt->execute([$hash]);
if ($stmt->rowCount()===0) $pdo->prepare("INSERT INTO settings(setting_key,setting_value) VALUES('admin_password_hash',?)")->execute([$hash]);
echo 'Password admin berhasil dibuat. HAPUS FILE admin/setup.php sekarang, lalu login di admin/login.php.';
