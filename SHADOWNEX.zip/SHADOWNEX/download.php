<?php
require_once __DIR__ . '/includes/functions.php';
$id = filter_input(INPUT_GET,'id',FILTER_VALIDATE_INT);
$stmt=$pdo->prepare("SELECT title,file_name,original_file_name FROM addons WHERE id=? AND status='approved' LIMIT 1");
$stmt->execute([$id ?: 0]); $a=$stmt->fetch();
if (!$a) { http_response_code(404); exit('Addon tidak ditemukan atau belum disetujui.'); }
$path=UPLOAD_ADDON_DIR . basename($a['file_name']);
if (!is_file($path)) { http_response_code(404); exit('File addon tidak tersedia.'); }
$pdo->prepare('UPDATE addons SET downloads=downloads+1 WHERE id=?')->execute([$id]);
$ext=strtolower(pathinfo($a['original_file_name'],PATHINFO_EXTENSION));
$downloadName=preg_replace('/[^A-Za-z0-9._-]/','_',basename($a['original_file_name'])) ?: ('addon.'.$ext);
header('X-Content-Type-Options: nosniff');
header('Content-Type: application/octet-stream');
header('Content-Length: '.filesize($path));
header('Content-Disposition: attachment; filename="'.$downloadName.'"');
readfile($path);
exit;
