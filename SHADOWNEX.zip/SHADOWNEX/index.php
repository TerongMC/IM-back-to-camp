<?php
require_once __DIR__ . '/includes/functions.php';
$page_title = 'Beranda';
$search = trim((string)($_GET['q'] ?? ''));
$sql = "SELECT a.*, c.name AS category_name FROM addons a JOIN categories c ON c.id=a.category_id WHERE a.status='approved'";
$params = [];
if ($search !== '') { $sql .= " AND (a.title LIKE ? OR a.description LIKE ? OR a.uploader_name LIKE ?)"; $like = '%' . $search . '%'; $params = [$like,$like,$like]; }
$sql .= " ORDER BY a.created_at DESC LIMIT 12";
$stmt = $pdo->prepare($sql); $stmt->execute($params); $addons = $stmt->fetchAll();
$categories = get_categories($pdo);
require __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <div>
    <span class="eyebrow">✦ MINECRAFT BEDROCK COMMUNITY</span>
    <h1>BEYOND<br>EVERY <span>BLOCK.</span></h1>
    <p>Temukan dan bagikan addon, resource pack, texture pack, UI, dan world untuk Minecraft Bedrock. Unggah tanpa login—cukup masukkan nama uploader.</p>
    <div class="actions"><a class="button" href="<?= e(BASE_URL) ?>/upload.php">＋ Upload Addon</a><a class="button secondary" href="<?= e(BASE_URL) ?>/search.php">Jelajahi Addon ↗</a></div>
  </div>
  <div class="hero-art" aria-label="SHADOWNEX"><div class="cube">⬡</div></div>
</section>
<div class="section-head"><div><h2>Jelajahi koleksi</h2><p>Addon terbaru yang telah disetujui admin.</p></div><a class="button secondary" href="<?= e(BASE_URL) ?>/search.php">Lihat semua →</a></div>
<form class="searchbar" action="<?= e(BASE_URL) ?>/search.php" method="get"><input class="search-input" id="addon-search" name="q" value="<?= e($search) ?>" placeholder="Cari addon, uploader, atau deskripsi..."><button class="button">Cari</button></form>
<div class="addon-grid">
<?php foreach ($addons as $a): ?>
  <article class="addon-card" data-addon-card>
    <a href="<?= e(BASE_URL) ?>/detail.php?id=<?= (int)$a['id'] ?>">
      <div class="thumb"><?php if ($a['thumbnail']): ?><img src="<?= e(BASE_URL . '/uploads/thumbnails/' . $a['thumbnail']) ?>" alt="<?= e($a['title']) ?>" loading="lazy"><?php else: ?><span class="placeholder">⬡</span><?php endif; ?></div>
      <div class="card-body"><span class="category"><?= e($a['category_name']) ?></span><h3><?= e($a['title']) ?></h3><p><?= e(mb_strimwidth($a['description'],0,100,'…','UTF-8')) ?></p><div class="meta"><span>Versi <?= e($a['version']) ?></span><span><?= e(format_size((int)$a['file_size'])) ?></span></div><div class="uploader">Diunggah oleh <b><?= e($a['uploader_name']) ?></b></div></div>
    </a>
  </article>
<?php endforeach; ?>
</div>
<?php if (!$addons): ?><div class="empty">Belum ada addon yang dipublikasikan. Jadilah yang pertama mengunggah!</div><?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
