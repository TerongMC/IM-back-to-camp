CREATE DATABASE IF NOT EXISTS shadownex CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE shadownex;

CREATE TABLE IF NOT EXISTS categories (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(80) NOT NULL UNIQUE,
  slug VARCHAR(100) NOT NULL UNIQUE
);
INSERT IGNORE INTO categories (name,slug) VALUES
('Addon','addon'),('Resource Pack','resource-pack'),('Texture Pack','texture-pack'),('UI','ui'),('World','world');

CREATE TABLE IF NOT EXISTS addons (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  uploader_name VARCHAR(80) NOT NULL,
  category_id INT UNSIGNED NOT NULL,
  title VARCHAR(150) NOT NULL,
  slug VARCHAR(180) NOT NULL UNIQUE,
  description TEXT NOT NULL,
  version VARCHAR(40) NOT NULL DEFAULT '1.0',
  file_name VARCHAR(255) NOT NULL,
  original_file_name VARCHAR(255) NOT NULL,
  thumbnail VARCHAR(255) DEFAULT NULL,
  file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
  downloads BIGINT UNSIGNED NOT NULL DEFAULT 0,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_status (status),
  INDEX idx_category (category_id),
  INDEX idx_created (created_at),
  CONSTRAINT fk_addons_category FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE IF NOT EXISTS settings (
  setting_key VARCHAR(100) PRIMARY KEY,
  setting_value TEXT NOT NULL
);
INSERT IGNORE INTO settings (setting_key,setting_value) VALUES
('site_name','SHADOWNEX'),
('site_slogan','Beyond Every Block.'),
('admin_password_hash','');
