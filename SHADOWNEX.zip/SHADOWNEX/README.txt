SHADOWNEX — Beyond Every Block.
================================

FITUR
- Beranda dan daftar addon publik.
- Upload tanpa login: nama uploader diisi sendiri.
- Mendukung .mcpack, .mcaddon, .mcworld, .zip maksimal 100 MB.
- Thumbnail JPG/PNG/WebP maksimal 5 MB.
- Upload masuk status pending sampai disetujui admin.
- Pencarian, kategori, halaman detail, download counter.
- Admin login, moderasi, hapus upload.

SYARAT HOSTING
- PHP 8.1+ dengan PDO MySQL, fileinfo, mbstring.
- MySQL/MariaDB.
- Hosting harus mengizinkan upload maksimal 100 MB.
- Untuk website publik gunakan HTTPS.

INSTALASI
1. Upload semua isi folder SHADOWNEX ke document root hosting atau folder /SHADOWNEX.
2. Buat database MySQL dan impor database.sql melalui phpMyAdmin.
3. Edit config/database.php dengan host, nama database, username, dan password database hosting.
4. Edit BASE_URL di config/config.php sesuai URL sebenarnya, tanpa slash di akhir.
   Contoh: https://domainkamu.com atau https://domainkamu.com/SHADOWNEX
5. Pastikan folder uploads/addons dan uploads/thumbnails dapat ditulis oleh PHP.
6. Buka https://domainkamu.com/admin/setup.php, buat password admin kuat minimal 12 karakter.
7. SEGERA hapus admin/setup.php dari hosting setelah password dibuat.
8. Login melalui /admin/login.php dan tinjau upload dari /admin/addons.php.
9. Tes upload file kecil, setujui dari panel admin, lalu tes download.

PENTING
- Nama uploader adalah nama yang diklaim pengunggah; tidak diverifikasi.
- Karena upload anonim, pasang moderasi, batas ukuran, backup, dan aturan penghapusan konten.
- Jangan jalankan setup.php berkali-kali atau biarkan file setup tersedia setelah digunakan.
- Jika hosting punya batas upload lebih kecil, atur upload_max_filesize dan post_max_size di panel hosting.
- Ini adalah kode sumber siap dipasang, bukan website yang otomatis online. Hosting dan database tetap diperlukan.
- .htaccess menggunakan sintaks Apache 2.4. Jika hosting bukan Apache, sesuaikan konfigurasi web server.
