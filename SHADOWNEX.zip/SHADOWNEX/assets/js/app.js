("use strict");
document.addEventListener("DOMContentLoaded", () => {
  const menuButton = document.querySelector("#menu-toggle");
  const menu = document.querySelector("#mobile-menu");
  if (menuButton && menu) {
    menuButton.addEventListener("click", () => {
      const open = menu.classList.toggle("open");
      menuButton.setAttribute("aria-expanded", String(open));
    });
  }

  const thumbnail = document.querySelector("#thumbnail");
  const preview = document.querySelector("#thumbnail-preview");
  if (thumbnail && preview) {
    thumbnail.addEventListener("change", () => {
      const file = thumbnail.files && thumbnail.files[0];
      if (!file) { preview.hidden = true; preview.removeAttribute("src"); return; }
      if (!["image/jpeg", "image/png", "image/webp"].includes(file.type) || file.size > 5 * 1024 * 1024) {
        alert("Pilih gambar JPG, PNG, atau WebP maksimal 5 MB.");
        thumbnail.value = ""; preview.hidden = true; return;
      }
      const reader = new FileReader();
      reader.onload = () => { preview.src = reader.result; preview.hidden = false; };
      reader.readAsDataURL(file);
    });
  }

  const addonFile = document.querySelector("#addon-file");
  const filename = document.querySelector("#addon-filename");
  if (addonFile && filename) {
    addonFile.addEventListener("change", () => {
      const file = addonFile.files && addonFile.files[0];
      filename.textContent = file ? `${file.name} (${formatSize(file.size)})` : "Belum ada file dipilih.";
    });
  }

  const search = document.querySelector("#addon-search");
  const cards = [...document.querySelectorAll("[data-addon-card]")];
  const empty = document.querySelector("#search-empty");
  if (search && cards.length) {
    search.addEventListener("input", () => {
      const q = search.value.trim().toLowerCase();
      let count = 0;
      cards.forEach(card => {
        const show = card.textContent.toLowerCase().includes(q);
        card.hidden = !show;
        if (show) count++;
      });
      if (empty) empty.hidden = count > 0;
    });
  }

  document.querySelectorAll("[data-confirm]").forEach(el => {
    el.addEventListener("click", event => {
      if (!confirm(el.dataset.confirm || "Yakin?")) event.preventDefault();
    });
  });
});
function formatSize(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / 1048576).toFixed(1) + " MB";
}
