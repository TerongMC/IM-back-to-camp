<?php
require_once __DIR__ . '/includes/functions.php';
$page_title = 'Jelajahi Addon';
$q = trim((string)($_GET['q'] ?? ''));
$cat = trim((string)($_GET['category'] ?? ''));
$page = max(1, (int)($_GET['page'] ?? 1)); $limit = 12; $offset = ($page-1)*$limit;
$where = ["a.status='approved'"]; $params = [];
if ($q !== '') { $where[] = '(a.title LIKE ? OR a.description LIKE ? OR a.uploader_name LIKE ?)'; $like='%'.$q.'%'; array_push($params,$like,$like,$like); }
if ($cat !== '') { $where[] = 'c.slug=?'; $params[]=$cat; }
$clause = implode(' AND ', $where);
$count = $pdo->prepare("SELECT COUNT(*) FROM addons a JOIN categories c ON c.id=a.category_id WHERE $clause"); $count->execute($params); $total=(int)$count->fetchColumn();
$stmt = $pdo->prepare("SELECT a.*,c.name AS category_name FROM addons a JOIN categories c ON c.id=a.category_id WHERE $clause ORDER BY a.created_at DESC LIMIT $limit OFFSET $offset"); $stmt->execute($params); $addons=$stmt->fetchAll();
$categories=get_categories($pdo);
require __DIR__ . '/includes/header.php';
?>
<div class="section-head"><div><h2>Jelajahi Addon</h2><p>Cari koleksi SHADOWNEX berdasarkan judul atau uploader.</p></div><a class="button" href="<?= e(BASE_URL) ?>/upload.php">＋ Upload</a></div>
<form class="searchbar" method="get"><input class="search-input" id="addon-search" name="q" value="<?= e($q) ?>" placeholder="Cari addon atau uploader..."><select class="search-input" name="category" aria-label="Kategori"><option value="">Semua kategori</option><?php foreach($categories as $c): ?><option value="<?= e($c['slug']) ?>" <?= $cat===$c['slug']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select><button class="button">Cari</button></form>
<div class="addon-grid"><?php foreach($addons as $a): ?><article class="addon-card" data-addon-card><a href="<?= e(BASE_URL) ?>/detail.php?id=<?= (int)$a['id'] ?>"><div class="thumb"><?php if($a['thumbnail']): ?><img src="<?= e(BASE_URL.'/uploads/thumbnails/'.$a['thumbnail']) ?>" alt="<?= e($a['title']) ?>" loading="lazy"><?php else: ?><span class="placeholder">⬡</span><?php endif; ?></div><div class="card-body"><span class="category"><?= e($a['category_name']) ?></span><h3><?= e($a['title']) ?></h3><p><?= e(mb_strimwidth($a['description'],0,100,'…','UTF-8')) ?></p><div class="meta"><span>Versi <?= e($a['version']) ?></span><span><?= e(format_size((int)$a['file_size'])) ?></span></div><div class="uploader">Diunggah oleh <b><?= e($a['uploader_name']) ?></b></div></div></a></article><?php endforeach; ?></div>
<p id="search-empty" class="empty" hidden>Tidak ada addon yang cocok dengan pencarian.</p>
<?php if (!$addons): ?><div class="empty">Addon tidak ditemukan. Coba kata kunci lain.</div><?php endif; ?>
<?php if ($total>$limit): ?><nav class="pagination"><?php for($p=1;$p<=ceil($total/$limit);$p++): ?><a href="?q=<?= urlencode($q) ?>&category=<?= urlencode($cat) ?>&page=<?= $p ?>" <?= $p===$page?'aria-current="page"':'' ?>><?= $p ?></a><?php endfor; ?></nav><?php endif; ?>
<?php require __DIR__ . '/includes/footer.php'; ?>
